# 모임 알림 추가분

기준: main 7db4f7d130e37582be6d7cc916679ed8ff5ba909.
이 변경은 로컬 작업본입니다. GitHub 반영이나 Firebase 배포는 수행하지 않았습니다.

## 범위

기존 파일 수정은 아래 3개로 제한했습니다.

- lib/views/map_screen.dart: 모임 시작 일시 입력 및 startsAt 저장·검증.
- lib/views/main_shell.dart: 기존 알림 수신을 전용 서비스에 연결하고 알림 클릭 시 모임 상세로 이동.
- lib/screens/my_meetups_screen.dart: 내 정보 상단에 알림 설정 버튼 추가.

새 파일: 알림 서비스, 알림 설정 화면, 시작 일시 입력 위젯, 별도 Functions 코드와 배포 설정.
캘린더, 테두리, 배지, 채팅 데이터 처리, 모임 참여 로직은 변경하지 않았습니다.
기존 firebase.json과 pubspec.yaml도 수정하지 않았습니다.

## 동작

1. 내 정보의 종 아이콘에서 관심 모임 알림을 켜고 현재 위치를 동네로 저장합니다.
   관심 카테고리는 기존 내 정보 설정을 사용합니다. 동네는 자동 추적하지 않습니다.
   반경은 1.5/3/5/8km입니다. 관심 알림은 기본 꺼짐이며 설정 후 새로 생성되는 모임부터 적용됩니다.
2. 새 모임 생성 시 실제 날짜·시작 시간을 입력합니다. 모집 마감은 기존과 같이 오늘의 시각이며,
   현재 이후이면서 시작 이전 또는 동일해야 합니다. 시작 일시 필드는 모집 마감과 별개입니다.
   모임 만료 기준은 실제 시작 후 3일로 저장해 미래 모임이 시작 전에 만료되지 않게 합니다.
3. 서버가 관심 카테고리·반경을 만족하는 사용자에게 새 모임 알림을 보냅니다.
   본인 모임, 이미 참여한 모임, 마감/취소/정원 초과 모임은 제외합니다.
4. 서버가 매분 startsAt까지 30분 이하 남은 모임을 확인하고 참여자에게 한 번 발송합니다.
   늦게 참여하거나 시작이 30분 이내인 새 모임이면 다음 확인 시 남은 분수로 알려줍니다.
   모집이 마감돼도 참여 일정 알림은 유지합니다. 취소/삭제/참여 취소는 발송 직전에 다시 확인합니다.
5. 기존 채팅 알림 표시를 유지합니다. 새 모임 알림은 클릭하면 해당 모임 상세로 이동합니다.
   앱 실행 중에는 로컬 팝업, 백그라운드에서는 FCM 시스템 알림을 사용합니다.

## 데이터

- meetings/{meetingId}.startsAt: 실제 시작 시각의 Firestore Timestamp.
- users/{uid}/private/notificationSettings: interestEnabled, remindersEnabled,
  radiusMeters, center {lat,lng}, updatedAt. 다른 사용자에게 동네 좌표를 공개하지 않습니다.
- users/{uid}.preferredCategories: 기존 관심 카테고리 그대로 사용.
- users/{uid}.fcmToken: 기존 단일 기기 토큰 방식 그대로 사용합니다.
- meeting_notification_deliveries/{hash}: 서버 전용 중복 발송 방지 기록과 임시 전송 예약.

시작 전 알림은 기본 켜짐입니다. 기존 모임은 startsAt이 없으므로 시간 값을 추측해서
알림을 보내지 않습니다. 기존 모임에 적용하려면 방장이 실제 시작 시각을 확인해 별도로
저장해야 합니다. 시작 시각이 바뀌면 새 시각 기준 알림이 다시 한 번 발송될 수 있습니다.

## 배포 전 필요 사항

1. Firebase 프로젝트의 Firestore 실제 위치를 확인하고 functions-notifications/index.js의
   region을 적절히 선택합니다. 기본값은 asia-northeast3입니다.
2. Cloud Functions와 Cloud Scheduler를 배포할 수 있는 Blaze 요금제·권한·API 설정을 확인합니다.
   배포는 비용이 발생할 수 있어 이 작업에서는 실행하지 않았습니다.
3. 저장소에 기존 Firestore Rules가 없으므로 콘솔에서 운영 중인 규칙을 먼저 확인합니다.
   functions-notifications/firestore-rules.snippet을 기존 규칙 안에 병합합니다.
   startsAt 허용, 본인 전용 설정, 서버 발송 기록 보호를 확인하고 기존 규칙 전체를 덮어쓰지 마세요.
4. 기존 Android FCM 설정과 알림 권한, iOS 사용 시 APNs 키·Push Notifications 권한이 필요합니다.
5. Node.js 22 및 Firebase CLI가 있는 개발 환경에서 다음을 실행합니다.

```sh
cd functions-notifications
npm install
npm test
cd ..
firebase deploy --project hyper-local-project --config firebase.notifications.json --only functions:meeting-notifications
```

기존 함수가 콘솔에 있다면 배포 계획을 확인해 다른 코드베이스 함수를 삭제하지 않도록 합니다.
별도 codebase와 firebase.notifications.json을 사용하므로 기존 firebase.json을 편집할 필요가 없습니다.
단일 startsAt 범위 쿼리와 기존 preferredCategories 배열 쿼리를 사용합니다.
운영 환경에 인덱스 면제 설정이 있으면 해당 필드 인덱스를 다시 활성화해야 합니다.

## 검증 결과와 한계

- 조건/취소/마감/참여/시간 경계/중복·실패 처리 및 실제 핸들러 모의 실행 테스트 15개 통과.
- 추가 Dart 파일과 수정 Dart 파일의 구문은 formatter로 확인했습니다.
- 현재 환경에 Firebase·지도 등 Flutter 의존성 캐시가 없어 오프라인 의존성 설치가 실패했습니다.
  따라서 Flutter 전체 분석·빌드, Functions 의존성 설치·에뮬레이터 테스트, 실제 푸시 수신은 미검증입니다.
- Android/iOS 네이티브 푸시를 대상으로 합니다. 웹 서비스 워커와 웹 푸시는 추가하지 않았습니다.
- 앱 알림 권한, 네트워크, OS 절전 정책에 따라 표시가 지연될 수 있어 정확히 30분을 보장하지 않습니다.
- 서버 예약과 발송 기록, Android tag/APNs collapse ID 및 실행 중 중복 표시 억제를 적용했습니다.
  FCM 전송과 Firestore 성공 기록은 원자적이지 않아 전송 직후 서버가 중단되는 극단적 경우에는
  재시도로 같은 알림이 다시 표시될 수 있습니다. 종료/취소 직후 이미 전달된 알림은 회수할 수 없습니다.
- 기존 단일 fcmToken 모델이므로 마지막에 등록한 기기 기준입니다. 다중 기기/로그아웃 시 토큰의
  완전한 소유권 이전은 별도 인증 흐름 변경 없이 보장할 수 없습니다.
- 회원 탈퇴 시 새 private 설정 문서와 서버 발송 기록은 자동 삭제되지 않습니다. Auth와 users 문서가
  없으면 발송 대상에서 제외됩니다. 별도 데이터 정리 정책은 운영 규칙에 맞춰 추가해야 합니다.

배포 후 실제 기기에서 관심/비관심·반경 밖·자기 모임·취소·만석, 30분/30분 미만,
중복 실행, 알림 클릭(앱 실행/백그라운드/종료), 알림 설정 끄기를 확인해야 합니다.

공식 참고:
- https://firebase.google.com/docs/cloud-messaging/flutter/receive-messages
- https://firebase.google.com/docs/functions/firestore-events
- https://firebase.google.com/docs/functions/schedule-functions
