import 'dart:async';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'map_screen.dart';
import 'gathering_list_screen.dart';
import '../screens/my_meetups_screen.dart';
import 'chat_list_screen.dart';
import '../services/chat_service.dart';
import '../services/meeting_notification_service.dart';
import '../models/gathering_model.dart';
import 'gathering_detail_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _selectedIndex = 0;

  late final MeetingNotificationService _notifications;
  bool _openingMeeting = false;

  final List<Widget> _screens = [
    const MapScreen(),
    GatheringListScreen(),
    ChatListScreen(),
    const MyMeetupsScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _notifications = MeetingNotificationService(
      onOpenMeeting: (id) => unawaited(_openMeeting(id)),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) unawaited(_notifications.initialize());
    });
  }

  Future<void> _openMeeting(String id) async {
    if (!mounted || _openingMeeting) return;
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    _openingMeeting = true;
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('meetings')
          .doc(id)
          .get();
      if (!mounted || FirebaseAuth.instance.currentUser?.uid != uid) return;
      final data = snapshot.data();
      if (data == null ||
          data['isCancelled'] == true ||
          ['cancelled', 'canceled', 'deleted'].contains(data['status'])) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('삭제되거나 취소된 모임입니다.')));
        return;
      }
      await Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (_) => GatheringDetailScreen(
            meetingId: id,
            meetupData: data,
            gathering: Gathering(
              title: (data['title'] ?? '모임').toString(),
              location: (data['dong'] ?? '').toString(),
              date: (data['time'] ?? '').toString(),
              description: (data['description'] ?? '').toString(),
            ),
          ),
        ),
      );
    } catch (_) {
      if (mounted)
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('모임 정보를 불러오지 못했습니다.')));
    } finally {
      _openingMeeting = false;
    }
  }

  @override
  void dispose() {
    unawaited(_notifications.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.green,
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.map), label: '지도'),
          BottomNavigationBarItem(icon: Icon(Icons.list), label: '모임 목록'),
          BottomNavigationBarItem(icon: _ChatTabIcon(), label: '채팅'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: '내 정보'),
        ],
      ),
    );
  }
}

class _ChatTabIcon extends StatelessWidget {
  const _ChatTabIcon();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<int>(
      stream: ChatService().totalUnreadCountStream(),
      builder: (context, snapshot) {
        final count = snapshot.data ?? 0;

        return Stack(
          clipBehavior: Clip.none,
          children: [
            const Icon(Icons.chat),
            if (count > 0)
              Positioned(
                right: -8,
                top: -6,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 5,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    count > 99 ? '99+' : '$count',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}
