import 'dart:async';
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// 기존 채팅 알림도 그대로 표시하며 모임 알림의 이동 정보만 추가합니다.
class MeetingNotificationService {
  static Future<void> _previousCleanup = Future<void>.value();
  final void Function(String meetingId) onOpenMeeting;
  final _local = FlutterLocalNotificationsPlugin();
  final List<StreamSubscription<dynamic>> _subscriptions = [];
  final Set<String> _shown = {};
  bool _disposed = false;
  String? _uid;
  String? _token;

  MeetingNotificationService({required this.onOpenMeeting});

  bool get _active =>
      !_disposed && FirebaseAuth.instance.currentUser?.uid == _uid;

  Future<void> initialize() async {
    if (kIsWeb ||
        (defaultTargetPlatform != TargetPlatform.android &&
            defaultTargetPlatform != TargetPlatform.iOS))
      return;
    _uid = FirebaseAuth.instance.currentUser?.uid;
    if (_uid == null) return;

    try {
      // 계정 전환 시 이전 계정의 토큰 폐기가 끝난 뒤 새 토큰을 받습니다.
      await _previousCleanup;
      if (!_active) return;
      await _local.initialize(
        settings: const InitializationSettings(
          android: AndroidInitializationSettings('@mipmap/ic_launcher'),
          iOS: DarwinInitializationSettings(
            requestAlertPermission: false,
            requestBadgePermission: false,
            requestSoundPermission: false,
          ),
        ),
        onDidReceiveNotificationResponse: (response) {
          final payload = response.payload;
          if (payload == null) return;
          try {
            final decoded = jsonDecode(payload);
            if (decoded is Map) _open(Map<String, dynamic>.from(decoded));
          } catch (_) {
            // 기존 알림의 다른 형식 payload는 모임 이동으로 처리하지 않습니다.
          }
        },
      );
      await _local
          .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin
          >()
          ?.createNotificationChannel(
            const AndroidNotificationChannel(
              'lightning_app_channel',
              '번개 모임 알림',
              importance: Importance.max,
            ),
          );
      if (!_active) return;
      await FirebaseMessaging.instance
          .setForegroundNotificationPresentationOptions(
            alert: false,
            badge: false,
            sound: false,
          );
      if (!_active) return;
      _subscriptions.add(
        FirebaseMessaging.onMessage.listen((message) {
          unawaited(
            _show(message).catchError((Object error) {
              debugPrint('[알림 표시 실패] $error');
            }),
          );
        }),
      );
      _subscriptions.add(
        FirebaseMessaging.onMessageOpenedApp.listen(
          (message) => _open(message.data),
        ),
      );
      _subscriptions.add(
        FirebaseMessaging.instance.onTokenRefresh.listen((token) {
          unawaited(
            _saveToken(token).catchError((Object error) {
              debugPrint('[알림 토큰 저장 실패] $error');
            }),
          );
        }),
      );

      final initial = await FirebaseMessaging.instance.getInitialMessage();
      if (initial != null) _open(initial.data);
      final localLaunch = await _local.getNotificationAppLaunchDetails();
      final payload = localLaunch?.notificationResponse?.payload;
      if (localLaunch?.didNotificationLaunchApp == true && payload != null) {
        try {
          _open(Map<String, dynamic>.from(jsonDecode(payload) as Map));
        } catch (_) {}
      }
      // 토큰 조회 실패가 위의 알림 수신·이동 핸들러 등록을 막지 않습니다.
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null) await _saveToken(token);
    } catch (error) {
      debugPrint('[알림 초기화 실패] $error');
    }
  }

  Future<void> _saveToken(String token) async {
    if (!_active) return;
    _token = token;
    await FirebaseFirestore.instance.collection('users').doc(_uid).set({
      'fcmToken': token,
    }, SetOptions(merge: true));
  }

  void _open(Map<String, dynamic> data) {
    if (!_active) return;
    if (data['recipientUid'] != null && data['recipientUid'] != _uid) return;
    if (!['interest_meeting', 'meeting_reminder'].contains(data['type']))
      return;
    final id = data['meetingId'];
    if (id is String && id.isNotEmpty && !id.contains('/')) onOpenMeeting(id);
  }

  Future<void> _show(RemoteMessage message) async {
    if (!_active || message.notification == null) return;
    if (message.data['recipientUid'] != null &&
        message.data['recipientUid'] != _uid)
      return;
    final eventId = message.data['eventId']?.toString() ?? message.messageId;
    if (eventId != null && !_shown.add(eventId)) return;
    if (_shown.length > 200) _shown.remove(_shown.first);
    await _local.show(
      id: (eventId ?? message.hashCode.toString()).hashCode & 0x7fffffff,
      title: message.notification!.title,
      body: message.notification!.body,
      payload: jsonEncode(message.data),
      notificationDetails: const NotificationDetails(
        android: AndroidNotificationDetails(
          'lightning_app_channel',
          '번개 모임 알림',
          importance: Importance.max,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
    );
  }

  Future<void> dispose() {
    _disposed = true;
    _previousCleanup = _stop();
    return _previousCleanup;
  }

  Future<void> _stop() async {
    for (final subscription in _subscriptions) {
      await subscription.cancel();
    }
    final uid = _uid;
    final token = _token;
    if (uid == null || token == null) return;
    try {
      await FirebaseMessaging.instance.deleteToken();
    } catch (error) {
      debugPrint('[알림 토큰 폐기 실패] $error');
    }
    try {
      final ref = FirebaseFirestore.instance.collection('users').doc(uid);
      // 다른 기기에서 갱신한 토큰은 지우지 않습니다.
      await FirebaseFirestore.instance.runTransaction((transaction) async {
        final snapshot = await transaction.get(ref);
        if (snapshot.data()?['fcmToken'] == token) {
          transaction.update(ref, {'fcmToken': FieldValue.delete()});
        }
      });
    } catch (_) {
      // 로그아웃 후 쓰기 권한이 사라졌거나 탈퇴한 경우.
    }
  }
}
