import 'package:flutter/material.dart';

/// 모집 마감과 별도로 저장하는 실제 모임 시작 일시.
class MeetingStartTimeField extends StatefulWidget {
  final ValueChanged<DateTime> onChanged;

  const MeetingStartTimeField({super.key, required this.onChanged});

  @override
  State<MeetingStartTimeField> createState() => _MeetingStartTimeFieldState();
}

class _MeetingStartTimeFieldState extends State<MeetingStartTimeField> {
  DateTime? _value;

  Future<void> _pick() async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      initialDate: _value ?? now,
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: now.add(const Duration(days: 365)),
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(
      context: context,
      initialTime: _value == null
          ? TimeOfDay.fromDateTime(now.add(const Duration(hours: 1)))
          : TimeOfDay.fromDateTime(_value!),
    );
    if (time == null || !mounted) return;
    final value = DateTime(
      date.year,
      date.month,
      date.day,
      time.hour,
      time.minute,
    );
    if (!value.isAfter(DateTime.now())) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('모임 시작은 현재보다 이후로 선택해주세요.')));
      return;
    }
    setState(() => _value = value);
    widget.onChanged(value);
  }

  @override
  Widget build(BuildContext context) {
    final value = _value;
    final label = value == null
        ? '모임 날짜·시작 시간 선택 (필수)'
        : '${value.year}.${value.month.toString().padLeft(2, '0')}.'
              '${value.day.toString().padLeft(2, '0')} '
              '${TimeOfDay.fromDateTime(value).format(context)}';
    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(label),
      subtitle: const Text('모집 마감과 별개입니다. 시작 30분 전에 알림을 보내요.'),
      trailing: const Icon(Icons.access_time),
      onTap: _pick,
    );
  }
}
