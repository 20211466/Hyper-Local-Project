import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class NotificationSettingsScreen extends StatefulWidget {
  const NotificationSettingsScreen({super.key});

  @override
  State<NotificationSettingsScreen> createState() =>
      _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState
    extends State<NotificationSettingsScreen> {
  bool _loading = true;
  bool _busy = false;
  bool _interest = false;
  bool _reminders = true;
  int _radius = 1500;
  Map<String, double>? _center;
  String? _error;

  DocumentReference<Map<String, dynamic>> get _ref => FirebaseFirestore.instance
      .collection('users')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('private')
      .doc('notificationSettings');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final data = (await _ref.get()).data() ?? <String, dynamic>{};
      if (!mounted) return;
      setState(() {
        _interest = data['interestEnabled'] == true;
        _reminders = data['remindersEnabled'] != false;
        final radius = (data['radiusMeters'] as num?)?.toInt();
        _radius = [1500, 3000, 5000, 8000].contains(radius) ? radius! : 1500;
        final center = data['center'];
        if (center is Map && center['lat'] is num && center['lng'] is num) {
          _center = {
            'lat': (center['lat'] as num).toDouble(),
            'lng': (center['lng'] as num).toDouble(),
          };
        }
        _loading = false;
      });
    } catch (_) {
      if (mounted)
        setState(() {
          _loading = false;
          _error = '알림 설정을 불러오지 못했습니다. 다시 열어주세요.';
        });
    }
  }

  Future<void> _setCenter() async {
    setState(() => _busy = true);
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw StateError('위치 서비스를 켜주세요.');
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        throw StateError('동네를 설정하려면 위치 권한이 필요합니다.');
      }
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 20),
      );
      if (!mounted) return;
      setState(
        () => _center = {'lat': position.latitude, 'lng': position.longitude},
      );
    } catch (error) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              error is StateError
                  ? error.message.toString()
                  : '현재 위치를 확인하지 못했습니다.',
            ),
          ),
        );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _save() async {
    if (_interest && _center == null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('먼저 알림을 받을 동네를 설정해주세요.')));
      return;
    }
    setState(() => _busy = true);
    try {
      await _ref.set({
        'interestEnabled': _interest,
        'remindersEnabled': _reminders,
        'radiusMeters': _radius,
        if (_center != null) 'center': _center,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      if (!mounted) return;
      Navigator.pop(context);
    } catch (_) {
      if (mounted)
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('알림 설정을 저장하지 못했습니다.')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('알림 설정')),
    body: _loading
        ? const Center(child: CircularProgressIndicator())
        : _error != null
        ? Center(child: Text(_error!))
        : ListView(
            padding: const EdgeInsets.all(16),
            children: [
              SwitchListTile(
                title: const Text('관심 모임 생성 알림'),
                subtitle: const Text('내 정보에 설정한 관심 카테고리의 새 모임을 알려줘요.'),
                value: _interest,
                onChanged: _busy
                    ? null
                    : (value) => setState(() => _interest = value),
              ),
              ListTile(
                title: Text(_center == null ? '알림을 받을 동네 설정' : '알림 동네 설정됨'),
                subtitle: const Text('현재 위치를 기준으로 저장해요. 이동해도 자동으로 바뀌지 않아요.'),
                trailing: const Icon(Icons.my_location),
                onTap: _busy ? null : _setCenter,
              ),
              DropdownButtonFormField<int>(
                initialValue: _radius,
                decoration: const InputDecoration(labelText: '동네 알림 반경'),
                items: [1500, 3000, 5000, 8000]
                    .map(
                      (radius) => DropdownMenuItem(
                        value: radius,
                        child: Text('${radius / 1000}km'),
                      ),
                    )
                    .toList(),
                onChanged: _busy
                    ? null
                    : (value) => setState(() => _radius = value!),
              ),
              const SizedBox(height: 16),
              SwitchListTile(
                title: const Text('모임 시작 전 알림'),
                subtitle: const Text(
                  '참여한 모임 시작 약 30분 전에 알려줘요.\n시작까지 30분 미만이면 다음 알림 확인 때 알려줘요.',
                ),
                value: _reminders,
                onChanged: _busy
                    ? null
                    : (value) => setState(() => _reminders = value),
              ),
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('휴대폰 설정에서도 앱 알림을 허용해주세요.'),
              ),
              ElevatedButton(
                onPressed: _busy ? null : _save,
                child: Text(_busy ? '처리 중…' : '저장'),
              ),
            ],
          ),
  );
}
