"use strict";

const MINUTE = 60 * 1000;

function millis(value) {
  if (value && typeof value.toMillis === "function") return value.toMillis();
  if (value instanceof Date) return value.getTime();
  return NaN;
}

function cancelled(meeting) {
  return !meeting || meeting.isCancelled === true ||
    ["cancelled", "canceled", "deleted"].includes(meeting.status);
}

function distanceMeters(a, b) {
  if (![a?.lat, a?.lng, b?.lat, b?.lng].every(Number.isFinite) ||
      Math.abs(a.lat) > 90 || Math.abs(b.lat) > 90 ||
      Math.abs(a.lng) > 180 || Math.abs(b.lng) > 180) return Infinity;
  const radians = (n) => n * Math.PI / 180;
  const dlat = radians(b.lat - a.lat);
  const dlng = radians(b.lng - a.lng);
  const h = Math.sin(dlat / 2) ** 2 + Math.cos(radians(a.lat)) *
    Math.cos(radians(b.lat)) * Math.sin(dlng / 2) ** 2;
  return 6371000 * 2 * Math.asin(Math.sqrt(Math.min(1, h)));
}

function interested(meeting, user, settings, uid, now) {
  if (cancelled(meeting) || !user || settings?.interestEnabled !== true) return false;
  if (uid === meeting.creatorId || meeting.participants?.includes(uid)) return false;
  if (!Array.isArray(user.preferredCategories) ||
      !user.preferredCategories.includes(meeting.category)) return false;
  if (meeting.isClosed === true || meeting.status === "closed") return false;
  const deadline = millis(meeting.deadline);
  if (!Number.isFinite(deadline) || deadline <= now) return false;
  const current = Number(meeting.currentParticipants ?? meeting.participants?.length ?? 0);
  const max = Number(meeting.maxParticipants ?? 4);
  if (!Number.isFinite(current) || !Number.isFinite(max) || current >= max) return false;
  const radius = settings.radiusMeters;
  if (!Number.isFinite(radius) || radius <= 0 || radius > 8000) return false;
  return distanceMeters(settings.center, {lat: meeting.lat, lng: meeting.lng}) <= radius;
}

function reminder(meeting, user, settings, uid, now, expectedStart) {
  if (cancelled(meeting) || !user || settings?.remindersEnabled === false) return false;
  if (!Array.isArray(meeting.participants) || !meeting.participants.includes(uid)) return false;
  const start = millis(meeting.startsAt);
  // 모집 마감/조기 마감은 모임 취소가 아니므로 시작 알림을 막지 않습니다.
  return Number.isFinite(start) && start === expectedStart &&
    start > now && start <= now + 30 * MINUTE;
}

module.exports = {MINUTE, millis, cancelled, distanceMeters, interested, reminder};
