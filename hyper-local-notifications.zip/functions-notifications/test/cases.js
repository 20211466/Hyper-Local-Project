"use strict";

const cases = [];
const test = (name, run) => cases.push({name, run});
const assert = require("node:assert/strict");
const {MINUTE, distanceMeters, interested, reminder} = require("../policy");
const {deliverOnce} = require("../delivery");

const now = Date.UTC(2026, 10, 27, 3);
const meeting = {
  title: "저녁 산책", category: "산책", creatorId: "host",
  participants: ["host", "member"], currentParticipants: 2, maxParticipants: 4,
  deadline: new Date(now + 10 * MINUTE), startsAt: new Date(now + 30 * MINUTE),
  lat: 37.5, lng: 127,
};
const user = {preferredCategories: ["산책"]};
const settings = {
  interestEnabled: true, remindersEnabled: true,
  center: {lat: 37.5, lng: 127}, radiusMeters: 1500,
};

test("관심 카테고리와 저장한 동네 반경이 모두 일치해야 발송", () => {
  assert.equal(interested(meeting, user, settings, "other", now), true);
  assert.equal(interested(meeting, {preferredCategories: ["공부"]}, settings, "other", now), false);
  assert.equal(interested(meeting, user, {...settings, center: {lat: 35, lng: 129}}, "other", now), false);
});

test("동네 미설정·알림 끔·좌표 오류·범위 초과는 관심 알림 제외", () => {
  for (const override of [
    {interestEnabled: false}, {center: null}, {radiusMeters: 0},
    {radiusMeters: 9000}, {center: {lat: 100, lng: 127}},
  ]) assert.equal(interested(meeting, user, {...settings, ...override}, "other", now), false);
  assert.equal(interested(meeting, user, undefined, "other", now), false);
  assert.equal(distanceMeters({lat: NaN, lng: 0}, {lat: 0, lng: 0}), Infinity);
});

test("본인 모임·이미 참여한 모임·정원 초과·마감·취소는 관심 알림 제외", () => {
  for (const uid of ["host", "member"]) {
    assert.equal(interested(meeting, user, settings, uid, now), false);
  }
  for (const override of [
    {currentParticipants: 4}, {deadline: new Date(now)},
    {isClosed: true}, {status: "closed"}, {isCancelled: true},
  ]) assert.equal(interested({...meeting, ...override}, user, settings, "other", now), false);
});

test("시작 30분 경계와 지난 모임·30분보다 먼 모임 처리", () => {
  const start = meeting.startsAt.getTime();
  assert.equal(reminder(meeting, user, settings, "member", now, start), true);
  assert.equal(reminder(meeting, user, settings, "member", now - 1, start), false);
  assert.equal(reminder(meeting, user, settings, "member", start, start), false);
});

test("30분 미만 남은 모임에 늦게 참여한 사람도 남은 시간 내 알림 가능", () => {
  assert.equal(reminder(meeting, user, settings, "member", now + 20 * MINUTE,
    meeting.startsAt.getTime()), true);
});

test("모집 조기마감은 시작 알림을 취소하지 않음", () => {
  assert.equal(reminder({...meeting, status: "closed", isClosed: true,
    deadline: new Date(now - MINUTE)}, user, settings, "member", now,
  meeting.startsAt.getTime()), true);
});

test("참여 취소·모임 삭제/취소·알림 끔·시작 변경은 발송 직전 제외", () => {
  const start = meeting.startsAt.getTime();
  assert.equal(reminder(meeting, user, settings, "other", now, start), false);
  assert.equal(reminder(undefined, user, settings, "member", now, start), false);
  assert.equal(reminder(meeting, undefined, settings, "member", now, start), false);
  assert.equal(reminder({...meeting, status: "cancelled"}, user, settings, "member", now, start), false);
  assert.equal(reminder(meeting, user, {...settings, remindersEnabled: false}, "member", now, start), false);
  assert.equal(reminder(meeting, user, settings, "member", now, start - MINUTE), false);
});

test("이전 데이터의 모집 마감 시간을 실제 시작 시간으로 추측하지 않음", () => {
  assert.equal(reminder({...meeting, startsAt: undefined}, user, settings, "member", now,
    meeting.deadline.getTime()), false);
});

test("예약 불가이면 발송하지 않음", async () => {
  let sent = false;
  assert.equal(await deliverOnce({
    reserve: async () => null,
    send: async () => { sent = true; },
  }), false);
  assert.equal(sent, false);
});

test("중복 실행에서도 하나의 예약만 발송", async () => {
  let reserved = false;
  let count = 0;
  const deps = {
    reserve: async () => {
      if (reserved) return null;
      reserved = true;
      return {token: "test"};
    },
    send: async () => { count++; return "message-id"; },
    finish: async () => {}, release: async () => {},
  };
  await Promise.all([deliverOnce(deps), deliverOnce(deps)]);
  assert.equal(count, 1);
});

test("발송 실패를 기록하고 재시도할 수 있도록 오류 전달", async () => {
  let released = false;
  const error = new Error("temporary failure");
  await assert.rejects(deliverOnce({
    reserve: async () => ({token: "test"}),
    send: async () => { throw error; },
    finish: async () => assert.fail("실패한 발송을 성공 처리하면 안 됨"),
    release: async (_, failure) => { assert.equal(failure, error); released = true; },
  }), /temporary failure/);
  assert.equal(released, true);
});

module.exports = [...cases, ...require('./handlers')];
