"use strict";
const test = require("node:test");
for (const {name, run} of require("./cases")) test(name, run);
