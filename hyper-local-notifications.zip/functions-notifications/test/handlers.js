"use strict";

const assert = require("node:assert/strict");
const Module = require("node:module");
const {MINUTE} = require("../policy");

// 네트워크나 실제 Firebase 프로젝트 없이 실제 index.js 핸들러를 실행합니다.
function harness() {
  const now = Date.now();
  const entries = new Map([
    ["meetings/m1", {
      title: "산책", category: "산책", creatorId: "host", participants: ["host", "u1"],
      lat: 37.5, lng: 127, currentParticipants: 2, maxParticipants: 4,
      deadline: new Date(now + 15 * MINUTE), startsAt: new Date(now + 29 * MINUTE),
    }],
    ["users/u1", {fcmToken: "token1", preferredCategories: ["산책"]}],
    ["users/u2", {fcmToken: "token2", preferredCategories: ["산책"]}],
    ["users/u2/private/notificationSettings", {
      interestEnabled: true, center: {lat: 37.5, lng: 127}, radiusMeters: 1500,
    }],
  ]);
  const deleted = Symbol("delete");
  const sent = [];
  const snapshot = (path) => ({
    id: path.split("/").at(-1), exists: entries.has(path), data: () => entries.get(path),
  });
  class Ref {
    constructor(path) { this.path = path; }
    collection(name) { return new Query(`${this.path}/${name}`); }
    async get() { return snapshot(this.path); }
  }
  class Query {
    constructor(path, filters = [], maximum = Infinity) {
      this.path = path; this.filters = filters; this.maximum = maximum;
    }
    doc(id) { return new Ref(`${this.path}/${id}`); }
    where(field, op, value) {
      return new Query(this.path, [...this.filters, {field, op, value}], this.maximum);
    }
    orderBy() { return this; }
    limit(maximum) { return new Query(this.path, this.filters, maximum); }
    startAfter() { throw new Error("이 테스트 데이터는 한 페이지만 사용합니다."); }
    async get() {
      const docs = [];
      for (const [path, data] of entries) {
        if (!path.startsWith(`${this.path}/`) || path.slice(this.path.length + 1).includes("/")) continue;
        const matches = this.filters.every(({field, op, value}) => {
          const actual = data[field];
          if (op === "array-contains") return actual?.includes(value);
          if (op === ">") return actual instanceof Date && actual.getTime() > value.toMillis();
          if (op === "<=") return actual instanceof Date && actual.getTime() <= value.toMillis();
          throw new Error(`지원하지 않는 테스트 연산자: ${op}`);
        });
        if (matches) docs.push(snapshot(path));
      }
      return {docs: docs.slice(0, this.maximum), size: Math.min(docs.length, this.maximum)};
    }
  }
  function write(ref, data, replace = false) {
    const value = replace ? {} : {...entries.get(ref.path)};
    for (const [key, item] of Object.entries(data)) {
      if (item === deleted) delete value[key];
      else value[key] = item;
    }
    entries.set(ref.path, value);
  }
  let chain = Promise.resolve();
  const db = {
    collection: (name) => new Query(name),
    runTransaction: (run) => {
      const result = chain.then(() => run({
        get: (ref) => ref.get(), set: (ref, value) => write(ref, value, true),
        update: (ref, value) => write(ref, value),
      }));
      chain = result.catch(() => {});
      return result;
    },
  };
  let sendError;
  const messaging = {send: async (message) => {
    if (sendError) throw sendError;
    sent.push(message);
    return `message-${sent.length}`;
  }};
  const stubs = {
    "firebase-admin/app": {initializeApp() {}},
    "firebase-admin/firestore": {
      getFirestore: () => db,
      Timestamp: {fromMillis: (ms) => ({toMillis: () => ms})},
      FieldValue: {serverTimestamp: () => new Date(), delete: () => deleted},
    },
    "firebase-admin/messaging": {getMessaging: () => messaging},
    "firebase-functions/v2/firestore": {onDocumentCreated: (_, handler) => handler},
    "firebase-functions/v2/scheduler": {onSchedule: (_, handler) => handler},
    "firebase-functions": {logger: {error() {}}},
  };
  const index = require.resolve("../index");
  delete require.cache[index];
  const originalLoad = Module._load;
  Module._load = function(id, parent, isMain) {
    return Object.hasOwn(stubs, id) ? stubs[id] : originalLoad.call(this, id, parent, isMain);
  };
  let handlers;
  try { handlers = require(index); } finally { Module._load = originalLoad; }
  return {entries, sent, handlers, setError: (error) => { sendError = error; }, event: {
    data: {data: () => entries.get("meetings/m1")},
    params: {meetingId: "m1"}, time: new Date(now).toISOString(),
  }};
}

module.exports = [
  {name: "실제 생성 핸들러: 관심 사용자 발송·모임 ID·중복 억제", run: async () => {
    const h = harness();
    await h.handlers.notifyInterestedMeeting(h.event);
    await h.handlers.notifyInterestedMeeting(h.event);
    assert.equal(h.sent.length, 1);
    assert.equal(h.sent[0].token, "token2");
    assert.equal(h.sent[0].data.meetingId, "m1");
    assert.equal(h.sent[0].data.recipientUid, "u2");
  }},
  {name: "실제 예약 핸들러: 참여자 발송·발송 기록·중복 억제", run: async () => {
    const h = harness();
    await h.handlers.notifyUpcomingMeetings();
    await h.handlers.notifyUpcomingMeetings();
    assert.equal(h.sent.length, 1);
    assert.equal(h.sent[0].token, "token1");
    assert.equal(h.sent[0].data.type, "meeting_reminder");
    assert.ok([...h.entries.values()].some((value) => value.status === "sent"));
  }},
  {name: "실제 예약 핸들러: 참여 취소·모임 취소 후 발송하지 않음", run: async () => {
    const h = harness();
    h.entries.get("meetings/m1").participants = ["host"];
    await h.handlers.notifyUpcomingMeetings();
    h.entries.get("meetings/m1").participants = ["u1"];
    h.entries.get("meetings/m1").status = "cancelled";
    await h.handlers.notifyUpcomingMeetings();
    assert.equal(h.sent.length, 0);
  }},
  {name: "실제 예약 핸들러: 무효 토큰 제거 후 새 토큰으로 복구", run: async () => {
    const h = harness();
    h.setError(Object.assign(new Error("invalid"), {code: "messaging/registration-token-not-registered"}));
    await h.handlers.notifyUpcomingMeetings();
    assert.equal(h.entries.get("users/u1").fcmToken, undefined);
    h.entries.get("users/u1").fcmToken = "replacement";
    h.setError(undefined);
    await h.handlers.notifyUpcomingMeetings();
    assert.equal(h.sent.length, 1);
    assert.equal(h.sent[0].token, "replacement");
  }},
];
