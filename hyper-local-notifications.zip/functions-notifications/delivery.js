"use strict";

/**
 * reserve는 최신 사용자·설정·참여 여부를 트랜잭션으로 검사합니다.
 * sent 기록과 lease로 재실행/동시 실행 중 중복 발송을 제한합니다.
 * FCM 발송과 Firestore 저장 사이의 프로세스 종료는 원자적으로 묶을 수 없습니다.
 */
async function deliverOnce({reserve, send, finish, release}) {
  const reservation = await reserve();
  if (!reservation) return false;
  try {
    const messageId = await send(reservation);
    await finish(reservation, messageId);
    return true;
  } catch (error) {
    await release(reservation, error);
    throw error;
  }
}

module.exports = {deliverOnce};
