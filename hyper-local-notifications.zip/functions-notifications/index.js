"use strict";

const {createHash, randomUUID} = require("node:crypto");
const {initializeApp} = require("firebase-admin/app");
const {getFirestore, Timestamp, FieldValue} = require("firebase-admin/firestore");
const {getMessaging} = require("firebase-admin/messaging");
const {onDocumentCreated} = require("firebase-functions/v2/firestore");
const {onSchedule} = require("firebase-functions/v2/scheduler");
const {logger} = require("firebase-functions");
const policy = require("./policy");
const {deliverOnce} = require("./delivery");

initializeApp();
const db = getFirestore();
const messaging = getMessaging();
const region = "asia-northeast3";
const invalidTokens = new Set([
  "messaging/registration-token-not-registered",
  "messaging/invalid-registration-token",
]);

async function notify(meetingId, uid, type, expectedStart) {
  const key = createHash("sha256")
    .update(JSON.stringify([meetingId, uid, type, expectedStart ?? "created"]))
    .digest("hex");
  const ledger = db.collection("meeting_notification_deliveries").doc(key);
  const meetingRef = db.collection("meetings").doc(meetingId);
  const userRef = db.collection("users").doc(uid);
  const settingsRef = userRef.collection("private").doc("notificationSettings");
  const owner = randomUUID();

  return deliverOnce({
    reserve: () => db.runTransaction(async (transaction) => {
      const [sentSnap, meetingSnap, userSnap, settingsSnap] = await Promise.all([
        transaction.get(ledger), transaction.get(meetingRef),
        transaction.get(userRef), transaction.get(settingsRef),
      ]);
      const now = Date.now();
      const sent = sentSnap.data();
      const user = userSnap.data();
      if (sent?.status === "sent") return null;
      if (sent?.status === "invalid-token" && sent.invalidToken === user?.fcmToken) return null;
      if (policy.millis(sent?.leaseUntil) > now) {
        const error = new Error("다른 실행이 같은 알림을 전송 중입니다.");
        error.code = "notification/in-flight";
        throw error;
      }
      const meeting = meetingSnap.data();
      const settings = settingsSnap.data();
      const eligible = type === "interest_meeting"
        ? policy.interested(meeting, user, settings, uid, now)
        : policy.reminder(meeting, user, settings, uid, now, expectedStart);
      if (!eligible || typeof user.fcmToken !== "string" || !user.fcmToken) return null;
      transaction.set(ledger, {
        owner, meetingId, uid, type, status: "sending",
        leaseUntil: Timestamp.fromMillis(now + 2 * policy.MINUTE),
        updatedAt: FieldValue.serverTimestamp(),
      });
      return {token: user.fcmToken, meeting};
    }),
    send: async ({token, meeting}) => {
      const ttl = type === "meeting_reminder"
        ? Math.max(1, expectedStart - Date.now())
        : 10 * policy.MINUTE;
      const title = type === "interest_meeting" ? "관심 모임이 생겼어요!" : "모임 시작 전 알림";
      const remaining = Math.max(1, Math.ceil((expectedStart - Date.now()) / policy.MINUTE));
      const body = type === "interest_meeting"
        ? `근처에 '${String(meeting.title ?? "새 모임").slice(0, 80)}' 모임이 생성됐어요.`
        : `'${String(meeting.title ?? "참여한 모임").slice(0, 80)}' 모임이 약 ${remaining}분 후 시작돼요.`;
      return messaging.send({
        token,
        notification: {title, body},
        data: {type, meetingId, recipientUid: uid, eventId: key},
        android: {
          priority: "high", ttl,
          notification: {channelId: "lightning_app_channel", tag: key},
        },
        apns: {
          headers: {
            "apns-collapse-id": key,
            "apns-expiration": String(Math.floor((Date.now() + ttl) / 1000)),
          },
          payload: {aps: {sound: "default"}},
        },
      });
    },
    finish: (_, messageId) => db.runTransaction(async (transaction) => {
      const snapshot = await transaction.get(ledger);
      if (snapshot.data()?.owner !== owner) return;
      transaction.update(ledger, {
        status: "sent", messageId, sentAt: FieldValue.serverTimestamp(),
        leaseUntil: FieldValue.delete(),
      });
    }),
    release: ({token}, error) => db.runTransaction(async (transaction) => {
      const [snapshot, userSnap] = await Promise.all([
        transaction.get(ledger), transaction.get(userRef),
      ]);
      if (snapshot.data()?.owner !== owner || snapshot.data()?.status === "sent") return;
      const invalid = invalidTokens.has(error.code);
      // 이미 전송한 뒤 finish만 실패했다면 lease를 유지해 즉시 재발송하지 않습니다.
      transaction.update(ledger, {
        status: invalid ? "invalid-token" : "retry",
        ...(invalid ? {invalidToken: token, leaseUntil: FieldValue.delete()} : {}),
        lastError: String(error.code ?? "unknown"),
        updatedAt: FieldValue.serverTimestamp(),
      });
      if (invalid && userSnap.data()?.fcmToken === token) {
        transaction.update(userRef, {fcmToken: FieldValue.delete()});
      }
    }),
  });
}

async function notifyBatch(items, makeArgs) {
  let failed = false;
  for (let i = 0; i < items.length; i += 5) {
    const results = await Promise.allSettled(
      items.slice(i, i + 5).map((item) => notify(...makeArgs(item))),
    );
    for (const result of results) {
      if (result.status === "rejected") {
        if (!invalidTokens.has(result.reason?.code)) failed = true;
        logger.error("모임 알림 전송 실패", {code: result.reason?.code ?? "unknown"});
      }
    }
  }
  return failed;
}

exports.notifyInterestedMeeting = onDocumentCreated({
  document: "meetings/{meetingId}", region, retry: true, timeoutSeconds: 540,
}, async (event) => {
  const data = event.data?.data();
  if (!data || typeof data.category !== "string" ||
      Date.now() - Date.parse(event.time) > 10 * policy.MINUTE) return;
  let cursor;
  let failed = false;
  while (true) {
    let query = db.collection("users")
      .where("preferredCategories", "array-contains", data.category)
      .orderBy("__name__").limit(100);
    if (cursor) query = query.startAfter(cursor);
    const page = await query.get();
    failed = (await notifyBatch(page.docs, (user) => [
      event.params.meetingId, user.id, "interest_meeting",
    ])) || failed;
    if (page.size < 100) break;
    cursor = page.docs[page.docs.length - 1];
  }
  if (failed) throw new Error("관심 모임 알림 일부 실패: 재시도 필요");
});

exports.notifyUpcomingMeetings = onSchedule({
  schedule: "every 1 minutes", timeZone: "Asia/Seoul", region,
  timeoutSeconds: 540, maxInstances: 1,
}, async () => {
  const now = Date.now();
  let cursor;
  while (true) {
    let query = db.collection("meetings")
      .where("startsAt", ">", Timestamp.fromMillis(now))
      .where("startsAt", "<=", Timestamp.fromMillis(now + 30 * policy.MINUTE))
      .orderBy("startsAt").limit(100);
    if (cursor) query = query.startAfter(cursor);
    const page = await query.get();
    for (const meeting of page.docs) {
      const data = meeting.data();
      const participants = Array.isArray(data.participants)
        ? [...new Set(data.participants.filter((id) => typeof id === "string" && id && !id.includes("/")))]
        : [];
      await notifyBatch(participants, (uid) => [
        meeting.id, uid, "meeting_reminder", policy.millis(data.startsAt),
      ]);
    }
    if (page.size < 100) break;
    cursor = page.docs[page.docs.length - 1];
  }
});
